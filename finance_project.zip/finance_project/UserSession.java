package finance_project;

public class UserSession {
    public static String currentUsername = null; // Static variable to hold the username
}